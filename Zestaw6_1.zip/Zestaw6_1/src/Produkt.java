public class Produkt
{
    String nazwa;
    int cena;
    int iloscNaMagazynie;

    public Produkt(String nazwa, int iloscNaMagazynie, int cena)
    {
        this.nazwa = nazwa;
        this.cena = cena;
        this.iloscNaMagazynie = iloscNaMagazynie;
    }
    public void dodajDoMagazynu(int ilosc)
    {
        this.iloscNaMagazynie += ilosc;
    }
    public void usunZMagazynu(int ilosc)
    {
        if(ilosc <= iloscNaMagazynie)
        {
            this.iloscNaMagazynie -= ilosc;
        }
    }
}
