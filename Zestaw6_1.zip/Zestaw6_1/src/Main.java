//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args)
    {
        // zad 1
        /*
        Produkt kanapka = new Produkt("kanapka",15,10);
        kanapka.dodajDoMagazynu(5);
        System.out.println("nazwa: "+kanapka.nazwa);
        System.out.println("iloscNaMagazynie: "+kanapka.iloscNaMagazynie);
        System.out.println("cena: "+kanapka.cena);
        kanapka.usunZMagazynu(19);
        System.out.println("nazwa: "+kanapka.nazwa);
        System.out.println("iloscNaMagazynie: "+kanapka.iloscNaMagazynie);
        System.out.println("cena: "+kanapka.cena);
         */
        // zad 2
    }
}