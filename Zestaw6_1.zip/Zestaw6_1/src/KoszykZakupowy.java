import java.util.*;

public class KoszykZakupowy
{
    List<String> nazwy;
    List<Integer> ilosc;

    public KoszykZakupowy(List<String> produkt,List<Integer> ilosc)
    {
        this.nazwy = produkt;
        this.ilosc = ilosc;
    }
    public void dodajProdukt(String produkt, int ilosc)
    {
        if(Produkt.iloscNaMagazynie)
            this.nazwy.add(produkt);
            this.ilosc.add(ilosc);
    }

}


