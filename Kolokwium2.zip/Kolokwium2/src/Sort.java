import java.util.Arrays;

abstract class Sort implements Comparable{
    public static <T> void SortDescending(T[] a)
    {
        Comparable[] aux = new Comparable[a.length];
        Arrays.sort(a);
        Arrays.sort(aux);
    }
}
