public class Main {
    public static void main(String[] args) {
        House house = new House(120,"blue",5);
        System.out.println(house.getNumberOfRooms());
    }
}