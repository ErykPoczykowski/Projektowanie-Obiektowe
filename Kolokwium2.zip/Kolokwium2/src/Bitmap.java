
public abstract class Bitmap extends ComputerGraphic{

    public Bitmap(int width, int height) {
        super(width,height);
    }
    @Override
    public abstract void loadFile();
    {

    }
    @Override
    public abstract void saveFile();
    {

    }
}
