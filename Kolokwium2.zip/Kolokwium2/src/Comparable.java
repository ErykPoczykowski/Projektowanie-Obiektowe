public interface Comparable {
    public <T> void SortDescending();
}
