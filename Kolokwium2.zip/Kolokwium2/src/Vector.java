public abstract class Vector extends ComputerGraphic{

    public Vector(int width, int height) {
        super(width,height);
    }
    @Override
    public abstract void loadFile();
    {

    }
    @Override
    public abstract void saveFile();
    {

    }
}

