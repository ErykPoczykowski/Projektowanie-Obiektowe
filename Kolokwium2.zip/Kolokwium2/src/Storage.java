class Storage<T> {
    public T item;


    public void store(T item) {
        this.item = item;
    }
    public T retrieve()
    {
        return item;
    }
}

