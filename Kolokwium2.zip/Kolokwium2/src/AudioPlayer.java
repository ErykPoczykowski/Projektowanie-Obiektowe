class AudioPlayer implements MediaPlayer{

    @Override
    public void play(String trackName) {

    }

    @Override
    public void pause() {

    }

    @Override
    public String getCurrentTrack() {
        return "";
    }
}