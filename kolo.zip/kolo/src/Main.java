import java.util.*;

public class Main {
    public static void main(String[] args)
    {
        // zad 1
        //int[] tab = {1,3,5,7,9,11};
        //System.out.println(ciagArytmetycznyRodzajuM(n,m,a1,r));
        // zad 2
        //int[] tab = {1,3,5,7,9,11};
        //System.out.println(czyCiagArytmetyczny(tab));
        // zad 3
        int[] tab = {1,4,9,16};
        System.out.println(czyCiagArytmetycznyRodzajuM(tab,3));
        // zad 4
        //int[] tab = {100,23,21,15,8,6,4};
        //podciag(tab);
        // zad 5
        //int[] tab = {1,2,0,3,5,1,2,3,4,5};
        //podciag2(tab,8);
        // zad 6
        // sekwencjaCollatza(10,5);
        // zad 7
        //minMaxSekwencjaCollatza(10,21);
    }
    /*
    public static boolean ciagArytmetycznyRodzajuM(int n,int m,int a1,int[]r)
    {
        int A1 = tab[0];
        int temp = A1;
        for (int i = 1; i < tab.length; i++)
        {

        }
        return true;
    }
    */
    public static boolean czyCiagArytmetycznyRodzajuM(int[] tab,int m)
    {
        if(m >= tab.length)
        {
            return false;
        }
        int[] temp = new int[tab.length-1];
        if( m==1 )
        {
            int r = tab[1] - tab[0];
            if(r == 0)
            {
                return false;
            }
            for (int i = 2; i < tab.length; i++)
            {
                if(tab[i]-tab[i-1] != r)
                {
                    return false;
                }

            }
            return true;
        }
        else
        {
            for (int j = 1; j < tab.length; j++)
            {
                temp[j - 1] = tab[j] - tab[j - 1];
            }
            return czyCiagArytmetycznyRodzajuM(temp,m-1);
        }
    }
    public static boolean czyCiagArytmetyczny(int[] tab)
    {
        int r = tab[1] - tab[0];
        for (int i = 2; i < tab.length; i++)
        {
            if(tab[i]-tab[i-1] != r)
            {
                return false;
            }

        }
        return true;
    }
    public static void podciag(int[] tab)
    {
        int len = tab.length;
        int min = tab[0];
        int poz = 0;
        int wynik = 0;
        for(int j=0;j<len;j++)
        {
            if(tab[j]<min)
            {
                min = tab[j];
                poz = j;
            }
        }
        if(poz > tab[tab.length-2])
        {
            for (int i = poz + 1; tab[i] > tab[i - 1]; i++) {
                wynik++;
            }
            wynik++;
            System.out.println("dlugosc wynosi: " + wynik);
        }
        else
        {
            System.out.println("dlugosc wynosi: " + wynik);
        }

    }
    public static void podciag2(int[] tab,int r)
    {
        int len = tab.length;
        int wynik = 0;
        int nowy = 0;
        for(int j=1;j<len;j++)
        {
            if(tab[j-1]+r == tab[j])
            {
                nowy++;
                System.out.println(nowy);
            }
            else if(nowy > wynik)
            {
                wynik = nowy;
            }
        }
        wynik = nowy;
        System.out.println("dlugosc wynosi: " + wynik);

    }
    public static void sekwencjaCollatza(int n,int c)
    {
        for(int i=0;i<n;i++)
        {
            if (c % 2 == 0)
            {
                c = c/2;
                System.out.println(i+1+": "+c+" ");
            }
            else
            {
                c = 3*c+1;
                System.out.println(i+1+": "+c+" ");
            }
        }
    }
    public static void minMaxSekwencjaCollatza(int n,int c)
    {
        int min = c;
        int max = c;
        for(int i=0;i<n;i++)
        {
            if (c % 2 == 0)
            {
                if(c < min)
                {
                    min = c;
                }
                if(c > max)
                {
                    max = c;
                }
                c = c/2;
            }
            else
            {
                if(c < min)
                {
                    min = c;
                }
                if(c > max)
                {
                    max = c;
                }
                c = 3*c+1;
            }
        }
        System.out.println("min="+min);
        System.out.println("max="+max);
    }
}