public abstract class UrzadzenieElektroniczne {
    public abstract void napraw();

    public abstract void uzyj();

    public abstract void zepsuj();

    public abstract void wlacz();

    public abstract void wylacz();
}