public abstract class Warzywo {
    public abstract void zjedz();

    public abstract void umyj();

    public abstract void smak();

}
