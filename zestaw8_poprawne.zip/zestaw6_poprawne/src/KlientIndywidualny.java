public class KlientIndywidualny extends Klient {
    public final String PESEL;

    public KlientIndywidualny(String PESEL) {
        this.PESEL = PESEL;
    }
}
