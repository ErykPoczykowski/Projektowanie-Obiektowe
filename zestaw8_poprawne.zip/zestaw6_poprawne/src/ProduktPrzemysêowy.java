public class ProduktPrzemysłowy extends Produkt {
}
