public abstract class Owoc {
    public abstract void zjedz();

    public abstract void umyj();

    public abstract void smak();

}
