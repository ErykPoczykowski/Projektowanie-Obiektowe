public class Main {
    public static void main(String[] args) {
        System.out.println("Zadanie 1: ");
        Produkt produkt = new Produkt("Ser", 4,50);
        produkt.wyswietlInformacje();
        produkt.dodajDoMagazynu(50);
        produkt.wyswietlInformacje();
        produkt.usunZMagazynu(90);
        produkt.wyswietlInformacje();

        System.out.println("Zadanie 2: ");
        KoszykZakupowy koszyk = new KoszykZakupowy();
        Produkt produkt1 = new Produkt("Awokado", 9.30,50);
        Produkt produkt2 = new Produkt("Mleko", 6.50,25);
        Produkt produkt3 = new Produkt("Szynka", 2.80,45);
        koszyk.dodajProdukt(produkt1, 1);
        koszyk.dodajProdukt(produkt2, 2);
        koszyk.dodajProdukt(produkt3, 1);
        koszyk.wyswietlZawartoscKoszyka();
        System.out.println("Wartosc koszyka: "+koszyk.obliczCalkowitaWartosc());
        produkt1.wyswietlInformacje();
        produkt2.wyswietlInformacje();
        produkt3.wyswietlInformacje();

        System.out.println("Zadanie 3:");
        Zamowienie zamowienie = new Zamowienie(koszyk, "Nie opłacony");
        zamowienie.wyswietlZamowienie();
        zamowienie.ustawStatusZamowienia("Opłacony");
        zamowienie.wyswietlZamowienie();

    }
}