import java.util.ArrayList;

public class Klient {
    private String imie;
    private String nazwisko;
    ArrayList<Zamowienie> listaZamowien = new ArrayList<>();

    public Klient(String imie, String nazwisko) {
        this.imie = imie;
        this.nazwisko = nazwisko;
    }

    public void dodajZamowienie(Zamowienie z) {
        listaZamowien.add(z);
    }

    public void wyswietlHistorieZamowien(){
        for(Zamowienie z : listaZamowien){
            z.wyswietlZamowienie();
        }
    }
/*
    public void obliczLacznyKosztZamowien(){
        for(Zamowienie z : listaZamowien){

        }
    }

 */
}
