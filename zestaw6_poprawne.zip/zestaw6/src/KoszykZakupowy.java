import java.util.ArrayList;

public class KoszykZakupowy {
    private ArrayList<Produkt> lista_produktow = new ArrayList<>();
    private ArrayList<Integer> ilosc_produktow = new ArrayList<>();

    public KoszykZakupowy() {
    }

    public void dodajProdukt(Produkt produkt, int ilosc) {
        if(produkt.getIloscNaMagazynie() > 0){
            lista_produktow.add(produkt);
            ilosc_produktow.add(ilosc);
            produkt.usunZMagazynu(ilosc);
        }
    }

    public void wyswietlZawartoscKoszyka(){
        int i = 0;
        for (Produkt produkt : lista_produktow) {
            System.out.println("Nazwa: "+produkt.getNazwa()+" Cena: "+produkt.getCena()+" Ilość w koszyku: "+ilosc_produktow.get(i));
            i++;
        }
    }

    public double obliczCalkowitaWartosc(){
        double suma = 0;
        int i = 0;
        for (Produkt produkt : lista_produktow) {
            suma += Math.round(produkt.getCena()*ilosc_produktow.get(i) * 100.0) / 100.0;
        }
        return suma;
    }
}
