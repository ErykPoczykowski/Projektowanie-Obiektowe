import java.util.ArrayList;
import java.util.Iterator;

public class Klient {
    private String imie;
    private String nazwisko;
    ArrayList<Zamowienie> listaZamowien = new ArrayList();

    public Klient(String imie, String nazwisko) {
        this.imie = imie;
        this.nazwisko = nazwisko;
    }

    public void dodajZamowienie(Zamowienie z) {
        this.listaZamowien.add(z);
    }

    public void wyswietlHistorieZamowien() {
        Iterator var1 = this.listaZamowien.iterator();

        while(var1.hasNext()) {
            Zamowienie z = (Zamowienie)var1.next();
            z.wyswietlZamowienie();
        }

    }
}
