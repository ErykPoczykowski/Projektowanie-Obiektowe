public class Produkt {
    private String nazwa;
    private double cena;
    private int iloscNaMagazynie;

    public Produkt(String nazwa, double cena, int iloscNaMagazynie) {
        this.nazwa = nazwa;
        this.cena = cena;
        this.iloscNaMagazynie = iloscNaMagazynie;
    }

    public void wyswietlInformacje() {
        System.out.println("Nazwa: " + this.nazwa + " Cena: " + this.cena + " Ilość na magazynie: " + this.iloscNaMagazynie);
    }

    public void dodajDoMagazynu(int ilosc) {
        this.iloscNaMagazynie += ilosc;
    }

    public void usunZMagazynu(int ilosc) {
        if (this.iloscNaMagazynie - ilosc > 0) {
            this.iloscNaMagazynie -= ilosc;
        }

    }

    public int getIloscNaMagazynie() {
        return this.iloscNaMagazynie;
    }

    public double getCena() {
        return this.cena;
    }

    public String getNazwa() {
        return this.nazwa;
    }
}
