import java.util.ArrayList;
import java.util.Iterator;

public class KoszykZakupowy {
    private ArrayList<Produkt> lista_produktow = new ArrayList();
    private ArrayList<Integer> ilosc_produktow = new ArrayList();

    public KoszykZakupowy() {
    }

    public void dodajProdukt(Produkt produkt, int ilosc) {
        if (produkt.getIloscNaMagazynie() > 0) {
            this.lista_produktow.add(produkt);
            this.ilosc_produktow.add(ilosc);
            produkt.usunZMagazynu(ilosc);
        }

    }

    public void wyswietlZawartoscKoszyka() {
        int i = 0;

        for(Iterator var2 = this.lista_produktow.iterator(); var2.hasNext(); ++i) {
            Produkt produkt = (Produkt)var2.next();
            System.out.println("Nazwa: " + produkt.getNazwa() + " Cena: " + produkt.getCena() + " Ilość w koszyku: " + this.ilosc_produktow.get(i));
        }

    }

    public double obliczCalkowitaWartosc() {
        double suma = 0.0;
        int i = 0;

        Produkt produkt;
        for(Iterator var4 = this.lista_produktow.iterator(); var4.hasNext(); suma += (double)Math.round(produkt.getCena() * (double)(Integer)this.ilosc_produktow.get(i) * 100.0) / 100.0) {
            produkt = (Produkt)var4.next();
        }

        return suma;
    }
}
