public class ProduktSpozywczy extends Produkt{
}
