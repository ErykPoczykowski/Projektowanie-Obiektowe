import java.util.Random;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        // zad 1
        //wypisz(generujTablice(15, 10, 15));
        // zad 2
        //wypiszTablice(generujTablice(15, 1, 15),5,10);
        // zad 3
        int[] tab = generujTablice(5, 0, 10);
        //ileNieparzystych(tab);
        //ileParzystych(tab);
        //ileDodatnich(tab);
        //ileUjemnych(tab);
        //ileZerowych(tab);
        //ileMaxymalnych(tab);
        //ileMinimalnych(tab);
        //ileUnikalnych(tab);
        //wypisz(tab);
        // zad 4
        //sumaDodatnich(tab);
        //sumaUjemnych(tab);
        //sumaOdwrotnosci(tab);
        //sredniaArytmetyczna(tab);
        //sredniaGeometryczna(tab);
        //sredniaHarmoniczna(tab);
        //wypisz(tab);
        // zad 5
        funkcjaLiniowa(tab,5,10);
        funkcjaKwadratowa(tab,5,10);
        funkcjaWykladnicza(tab,5,10);
        funkcjaSignum(tab,5,10);
        wypisz(tab);
        // zad 7
        //generujTabliceR(20, -10, 152);
        //wypisz(tab);
    }
    public static void wypisz(int[] tab)
    {
        for (int i = 0; i < tab.length; i++)
        {
            System.out.print(tab[i] + " ");
        }
    }

    public static int[] generujTablice(int n, int minWartosc, int maxWartosc)
    {
        int[] tab = new int[n];
        for (int i = 0; i < n; i++) {
            tab[i] = (int) (minWartosc + Math.random() * (maxWartosc - minWartosc));
        }
        return tab;
    }

    public static void wypiszTablice(int[] tab, int n, int m)
    {
        int s = 0;
        for(int i = 0;i<m;i++)
        {
            System.out.print("\n");
            for(int j = 0;j<n;j++)
            {
                if(s<tab.length)
                {
                    if (j < n - 1)
                        System.out.print(tab[s] + " ");
                    else
                        System.out.print(tab[s]);
                }
                else
                    if (j < n - 1)
                        System.out.print("   ");
                    else
                        System.out.print(" ");

                s++;
            }
        }
    }
    public static void ileNieparzystych(int[] tab)
    {
        int ilosc = 0;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]%2==1)
            {
                ilosc++;
            }
        }
        System.out.print("wynik: ["+ilosc+"] ");
    }
    public static void ileParzystych(int[] tab)
    {
        int ilosc = 0;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]%2==0)
            {
                ilosc++;
            }
        }
        System.out.print("wynik: ["+ilosc+"] ");
    }
    public static void ileDodatnich(int[] tab)
    {
        int ilosc = 0;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]>=0)
            {
                ilosc++;
            }
        }
        System.out.print("wynik: ["+ilosc+"] ");
    }
    public static void ileUjemnych(int[] tab)
    {
        int ilosc = 0;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]<0)
            {
                ilosc++;
            }
        }
        System.out.print("wynik: ["+ilosc+"] ");
    }
    public static void ileZerowych(int[] tab)
    {
        int ilosc = 0;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]==0)
            {
                ilosc++;
            }
        }
        System.out.print("wynik: ["+ilosc+"] ");
    }
    public static void ileMaxymalnych(int[] tab)
    {
        int ilosc = 1;
        int maks = tab[0];
        for(int i = 1;i<tab.length;i++)
        {
            if(tab[i]>maks)
            {
                maks=tab[i];
                ilosc = 0;
            }
            if(tab[i]==maks)
            {
                ilosc++;
            }
        }
        System.out.print("wynik: ["+ilosc+"] ");
    }
    public static void ileMinimalnych(int[] tab)
    {
        int ilosc = 1;
        int min = tab[0];
        for(int i = 1;i<tab.length;i++)
        {
            if(tab[i]<min)
            {
                min=tab[i];
                ilosc = 0;
            }
            if(tab[i]==min)
            {
                ilosc++;
            }
        }
        System.out.print("wynik: ["+ilosc+"] ");
    }
    public static void ileUnikalnych(int[] tab)
    {
        long unique = Arrays.stream(tab).distinct().count();
        System.out.print("wynik: ["+unique+"] ");
    }
    public static void sumaDodatnich(int[] tab)
    {
        int suma = 0;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]>=0)
            {
                suma+=tab[i];
            }
        }
        System.out.print("wynik: ["+suma+"] ");
    }
    public static void sumaUjemnych(int[] tab)
    {
        int suma = 0;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]<0)
            {
                suma+=tab[i];
            }
        }
        System.out.print("wynik: ["+suma+"] ");
    }
    public static void sumaOdwrotnosci(int[] tab)
    {
        float suma = 0;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]!=0)
            {
                suma+=1/tab[i];
            }
        }
        System.out.print("wynik: ["+suma+"] ");
    }
    public static void sredniaArytmetyczna(int[] tab)
    {
        float suma = 0;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]!=0)
            {
                suma+=tab[i];
            }
        }
        float srednia = suma/tab.length;;
        System.out.print("wynik: ["+srednia+"] ");
    }
    public static void sredniaGeometryczna(int[] tab)
    {
        float suma = 0;
        float dlugosc = tab.length;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]!=0)
            {
                suma+=tab[i];
            }
        }
        double srednia = Math.pow(suma,  1/dlugosc);;
        System.out.print("wynik: ["+srednia+"] ");
    }
    public static void sredniaHarmoniczna(int[] tab)
    {
        double suma = 0.0;
        float dlugosc = tab.length;
        for(int i = 0;i<tab.length;i++)
        {
            if(tab[i]!=0)
            {
                suma+=(double)(1./tab[i]);
            }
        }
        double srednia = dlugosc/suma;
        System.out.print("wynik: ["+srednia+"] ");
    }
    public static void funkcjaLiniowa(int[] tab,int a,int b)
    {
        for (int i = 0; i < tab.length; i++)
        {
            System.out.print(a*tab[i]+b + " ");
        }
    }

    public static void funkcjaKwadratowa(int[] tab,int a,int b) {
        for (int i = 0; i < tab.length; i++) {
            System.out.print(a * tab[i] + b + " ");
        }
    }
    public static void funkcjaKwadratowa(int[] tab,int a,int b) {
        for (int i = 0; i < tab.length; i++) {
            System.out.print(a * tab[i] + b + " ");
        }
    }
        funkcjaWykladnicza(tab,5,10);
    funkcjaSignum(tab,5,10);



















    public static void generujTablice7(int n, int minWartosc, int maxWartosc)
    {
        int[] tab = new int[n];
        for (int i = 0; i < n; i++) {
            tab[i] = (int) (minWartosc + Math.random() * (maxWartosc - minWartosc));
        }

        for (int i = 0; i < n; i++)
        {
            System.out.printf("% 4d", tab[i]);
        }
    }
}
